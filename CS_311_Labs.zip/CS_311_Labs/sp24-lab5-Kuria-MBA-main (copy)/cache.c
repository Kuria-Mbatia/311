#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include "cache.h"

static cache_entry_t *cache = NULL;
static int cache_size = 0;
static int clock = 0;
static int num_queries = 0;
static int num_hits = 0;

/* Returns 1 on success and -1 on failure. Should allocate a space for
 * |num_entries| cache entries, each of type cache_entry_t. Calling it again
 * without first calling cache_destroy (see below) should fail. */
int cache_create(int num_entries)
{
  // Step 1 and 2: Check if cache exists and validate num_entries
  if (cache != NULL || num_entries < 2 || num_entries > 4096)
  {
    return -1; // Indicate failure
  }

  // Step 3: Allocate memory for the cache
  cache = (cache_entry_t *)malloc(num_entries * sizeof(cache_entry_t));
  if (cache == NULL)
  {
    return -1; // Memory allocation failed
  }

  // Step 4: Initialize cache entries
  for (int i = 0; i < num_entries; ++i)
  {
    cache[i].valid = false;
    cache[i].disk_num = -1;
    cache[i].block_num = -1;
    // No need to initialize cache[i].block
    cache[i].access_time = 0;
  }

  // Step 5: Set global variables
  cache_size = num_entries;
  clock = 0;
  num_queries = 0;
  num_hits = 0;

  return 1; // Success
}

int cache_destroy(void)
{
  // Step 1: Check if cache exists
  if (cache == NULL)
  {
    return -1; // cache does not exist
  }

  // Step 2: Free the cache memory
  free(cache);

  // Step 3: Reset global variables
  cache = NULL;
  cache_size = 0;
  clock = 0;

  return 1; //  success
}
int cache_lookup(int disk_num, int block_num, uint8_t *buf) {
    if (cache == NULL || cache_size == 0 || buf == NULL) {
        // Cache is not initialized, or buffer is NULL.
        return -1;
    }

    num_queries++; // Increment query count

    for (int i = 0; i < cache_size; ++i) {
        if (cache[i].valid && cache[i].disk_num == disk_num && cache[i].block_num == block_num) {
            // Found the matching entry; copy its data to buf.
            memcpy(buf, cache[i].block, JBOD_BLOCK_SIZE);
            cache[i].access_time = ++clock; // Update the access time
            num_hits++; // Increment hit count
            return 1; // Successful lookup, return 1
        }
    }

    // No matching entry found
    return -1;
}

void cache_update(int disk_num, int block_num, const uint8_t *buf) {
    if (cache == NULL || cache_size == 0) {
        // Cache has not been initialized, return.
        return;
    }

    for (int i = 0; i < cache_size; ++i) {
        if (cache[i].valid && cache[i].disk_num == disk_num && cache[i].block_num == block_num) {
            // Found the matching entry; update it.
            memcpy(cache[i].block, buf, JBOD_BLOCK_SIZE);
            cache[i].access_time = ++clock; // Update access_time only if entry is valid
            return; // Successfully updated the entry.
        }
    }
    // Entry not found; depending on your design, you might want to insert here.
}



int cache_insert(int disk_num, int block_num, const uint8_t *buf) {
    if (cache == NULL || cache_size <= 0 || buf == NULL) {
        return -1;
    }
    if (disk_num < 0 || block_num < 0 || disk_num >= 16 || block_num >= 256) {
        return -1; // Fail for invalid disk or block numbers
    }
    int lru_index = -1; // Index of the LRU entry
    int empty_index = -1; // Index of an empty (unused) entry, if found
    int min_access_time = __INT_MAX__; // Initialize with the maximum possible int value

    num_queries++; // Increment query count for every insertion operation

    // Search for an existing entry or the LRU entry
    for (int i = 0; i < cache_size; ++i) {
        if (cache[i].valid) {
            if (cache[i].disk_num == disk_num && cache[i].block_num == block_num) {
                // Existing entry found, increment hit count and return -1 to indicate failure
                num_hits++;
                return -1;
            }

            // Track the least recently used entry
            if (cache[i].access_time < min_access_time) {
                min_access_time = cache[i].access_time;
                lru_index = i;
            }
        } else if (empty_index == -1) {
            // Track the first empty entry found
            empty_index = i;
        }
    }

    // Prefer using an empty entry if available
    if (empty_index != -1) {
        cache[empty_index].valid = true;
        cache[empty_index].disk_num = disk_num;
        cache[empty_index].block_num = block_num;
        memcpy(cache[empty_index].block, buf, JBOD_BLOCK_SIZE);
        cache[empty_index].access_time = ++clock;
        return 1; // Return 1 for successful insertion
    }

    // Use the LRU entry if no empty entries are available
    if (lru_index != -1) {
        cache[lru_index].valid = true; // Mark the LRU entry as valid
        cache[lru_index].disk_num = disk_num;
        cache[lru_index].block_num = block_num;
        memcpy(cache[lru_index].block, buf, JBOD_BLOCK_SIZE);
        cache[lru_index].access_time = ++clock;
        return 1; // Return 1 for successful insertion
    } 

    
    return -1;
}


  


bool cache_enabled(void)
{
  return (cache_size >= 2);
}

void cache_print_hit_rate(void)
{
   
  
    fprintf(stderr, "Hit rate: %5.1f%%\n", 100 * (float)num_hits / num_queries);
  
}
