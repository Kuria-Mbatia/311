/* Author:    Kuria Mbatia
   Date: 4/1/2024
    */
    
    
    
/***
 *      ______ .___  ___. .______     _______.  ______              ____    __   __  
 *     /      ||   \/   | |   _  \   /       | /      |            |___ \  /_ | /_ | 
 *    |  ,----'|  \  /  | |  |_)  | |   (----`|  ,----'              __) |  | |  | | 
 *    |  |     |  |\/|  | |   ___/   \   \    |  |                  |__ <   | |  | | 
 *    |  `----.|  |  |  | |  |   .----)   |   |  `----.             ___) |  | |  | | 
 *     \______||__|  |__| | _|   |_______/     \______|            |____/   |_|  |_| 
 *                                                                                   
 */


#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "mdadm.h"
#include "jbod.h"
#include "util.h"
#include "cache.h"
int mounted = 0;

uint32_t op_code(jbod_cmd_t com, int disk_num, int block_num) {
    uint32_t op = (disk_num << 28)|block_num << 20 |(com << 14);
    return(op);///grabbing the correct section of the oepration 
}

int mdadm_mount(void) {
    if (mounted) {//if already mounted dont mount again
        return -1;
    }
    jbod_operation(op_code(JBOD_MOUNT, 0, 0), NULL);
    mounted = 1;//cahnge mount
    return 1;
}

int mdadm_unmount(void) {///ROD mdadm_mount :/ 
    if (!mounted) {
        return -1;
    }
    jbod_operation(op_code(JBOD_UNMOUNT, 0, 0), NULL);
    mounted = 0;
    return 1;
}



int mdadm_read(uint32_t addr, uint32_t len, uint8_t *buf) {
    if (!len) {
        return 0; 
    }
    if (!mounted || len > 1024 || buf == NULL || addr + len > JBOD_NUM_DISKS * JBOD_DISK_SIZE) {
        return -1; // Invalid parameters
    }

    uint32_t ref_addy = addr;
    uint32_t end_addr = addr + len;
    uint8_t *buf_ptr = buf;

    
    while (ref_addy < end_addr) {
        int disk_num = ref_addy / JBOD_DISK_SIZE;
        int block_num = (ref_addy % JBOD_DISK_SIZE) / JBOD_BLOCK_SIZE;
        int block_offset = ref_addy % JBOD_BLOCK_SIZE;
        int read_len = JBOD_BLOCK_SIZE - block_offset;
        
        if (ref_addy + read_len > end_addr) {
            read_len = end_addr - ref_addy;
        }
        
        uint8_t block[JBOD_BLOCK_SIZE];
        
        if (cache_enabled()) {
            // Check if the block is in the cache
            if (cache_lookup(disk_num, block_num, block) == 1) {
                // Cache hit, copy data from cache
                memcpy(buf_ptr, block + block_offset, read_len);
            } else {
                // Cache miss, seek to the correct disk and block, then read from JBOD
                jbod_operation(op_code(JBOD_SEEK_TO_DISK, disk_num, 0), NULL);
                jbod_operation(op_code(JBOD_SEEK_TO_BLOCK, 0, block_num), NULL);
                jbod_operation(op_code(JBOD_READ_BLOCK, 0, 0), block);
                
                // Insert the block into the cache
                cache_insert(disk_num, block_num, block);
                
                memcpy(buf_ptr, block + block_offset, read_len);
            }
        } else {
            // Cache disabled, seek to the correct disk and block, then read from JBOD
            jbod_operation(op_code(JBOD_SEEK_TO_DISK, disk_num, 0), NULL);
            jbod_operation(op_code(JBOD_SEEK_TO_BLOCK, 0, block_num), NULL);
            jbod_operation(op_code(JBOD_READ_BLOCK, 0, 0), block);

            memcpy(buf_ptr, block + block_offset, read_len);
        }

        ref_addy += read_len;
        buf_ptr += read_len;
        block_num++;
    }

    return len; ////
}

// ... (include statements and other functions remain the same)

int mdadm_write(uint32_t addr, uint32_t len, const uint8_t *buf)
{
  if (!len)
  {
    return 0;
  }
  if (!mounted || len > 1024 || buf == NULL || addr + len > JBOD_NUM_DISKS * JBOD_DISK_SIZE)
  {
    return -1;
  }

  uint32_t ref_addr = addr;
  uint32_t end_addr = addr + len;
  
  const uint8_t *buf_ptr = buf;

  while (ref_addr < end_addr)
  {
    int disk_num = ref_addr / JBOD_DISK_SIZE;
    int block_num = (ref_addr % JBOD_DISK_SIZE) / JBOD_BLOCK_SIZE;
    int block_offset = ref_addr % JBOD_BLOCK_SIZE;
    int write_len = JBOD_BLOCK_SIZE - block_offset;

    if (ref_addr + write_len > end_addr)
    {
      write_len = end_addr - ref_addr;
    }

    uint8_t block[JBOD_BLOCK_SIZE];

    if (cache_enabled()) {
            // Check if the block is in the cache
            if (cache_lookup(disk_num, block_num, block) == 1) {
                // Cache hit, update the block in the cache
                memcpy(block + block_offset, buf_ptr, write_len);
                cache_update(disk_num, block_num, block);
            } else {
                // Cache miss, seek to the correct disk and block, then read from JBOD
                jbod_operation(op_code(JBOD_SEEK_TO_DISK, disk_num, 0), NULL);
                jbod_operation(op_code(JBOD_SEEK_TO_BLOCK, 0, block_num), NULL);
                jbod_operation(op_code(JBOD_READ_BLOCK, 0, 0), block);
                memcpy(block + block_offset, buf_ptr, write_len);
                cache_insert(disk_num, block_num, block);
            }

            // Write the updated block back to JBOD
            jbod_operation(op_code(JBOD_SEEK_TO_DISK, disk_num, 0), NULL);
            jbod_operation(op_code(JBOD_SEEK_TO_BLOCK, 0, block_num), NULL);
            jbod_operation(op_code(JBOD_WRITE_BLOCK, 0, 0), block);
        } else {
            // Cache disabled, seek to the correct disk and block, then read from JBOD
            jbod_operation(op_code(JBOD_SEEK_TO_DISK, disk_num, 0), NULL);
            jbod_operation(op_code(JBOD_SEEK_TO_BLOCK, 0, block_num), NULL);
            jbod_operation(op_code(JBOD_READ_BLOCK, 0, 0), block);
            memcpy(block + block_offset, buf_ptr, write_len);
            
            // Write the updated block back to JBOD
            jbod_operation(op_code(JBOD_SEEK_TO_DISK, disk_num, 0), NULL);
            jbod_operation(op_code(JBOD_SEEK_TO_BLOCK, 0, block_num), NULL);
            jbod_operation(op_code(JBOD_WRITE_BLOCK, 0, 0), block);
        }

        ref_addr += write_len;
        buf_ptr += write_len;
        block_num++;
    }

    return len;
}
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab4-Kuria-MBA-main */
