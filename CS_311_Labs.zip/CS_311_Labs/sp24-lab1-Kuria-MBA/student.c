/* Author: Kuria Mbatia 
   Date: 1/31/2024
    */

/***
 *      ______ .___  ___. .______     _______.  ______        ____    __   __  
 *     /      ||   \/   | |   _  \   /       | /      |      |___ \  /_ | /_ | 
 *    |  ,----'|  \  /  | |  |_)  | |   (----`|  ,----'        __) |  | |  | | 
 *    |  |     |  |\/|  | |   ___/   \   \    |  |            |__ <   | |  | | 
 *    |  `----.|  |  |  | |  |   .----)   |   |  `----.       ___) |  | |  | | 
 *     \______||__|  |__| | _|   |_______/     \______|      |____/   |_|  |_| 
 *                                                                                   
 */


#include "student.h"

// Takes an array of integers and the length of the array as input, and returns
// the smallest integer in the array
int smallest(int *array, int length) {
  /* YOUR CODE */
  ////jsut sort through the array and find the smallest number...
  for(int a = 0; a < length; a++)
  {
    for(int b = 0; b < length-1; b++)
    {
      if(array[b] > array[b+1])
      {
        int temp = array[b];
        array[b] = array[b+1];///swap
        array[b+1] = temp;
      }
    }
  }
return array[0];

}

// Takes an array of integers and the length of the array as input, and returns
// the product of the integers in the array.
int product(int *array, int length) {
  int compute = 1;
  for(int a = 0; a < length; a++)
  {
    compute = compute * array[a];
  }
  return compute;
}

// Takes pointers to two integers and swaps the values of integers
void swap(int *a, int *b) {
  int temp = *a;
  *a = *b;
  *b = temp;
  
  
}

// Rotate values of integers
void rotate(int *a, int *b, int *c) {
  int temp = *a;
  int temp2 = *b;
  *a = *c;
  *b = temp;
  *c = temp2;
}

// Sorts an array in descending order
void sort(int *array, int length) {
  for(int a = 0; a < length; a++)
  {
    for(int b = 0; b < length-1; b++)
    {
      if(array[b+1] > array[b])
      {
        int temp = array[b];
        array[b] = array[b+1];///swap
        array[b+1] = temp;
      }
    }
  }
}

int prime(int n) {
  if(n <= 1)
  {
    return 0;
  }
  for(int a = 2; a < n; a++)
  {
    if(n % a == 0)
    {
      return 0;
    }
  }
  return 1;
}
// Takes an array of integers and the length of the array as input and halves
// every prime element of the array
void halve_primes(int *array, int length) {
  for(int a = 0; a < length; a++)
  {
    if(prime(array[a]))
    {
      array[a] = array[a] / 2;
    }
  }
}

int strongarms(int val) {
    int store = val;
    int send = 0;
    while(store != 0) {
        int temp = store % 10;
        send = send + (temp * temp * temp);
        store = store / 10;

    }
    if((send == val)) {
        return 1;
    } else {
        return 0;
    }
}
// Takes an array of integers and the length of the array as input and square
// every positive element of the array that is an Armstrong number.
void square_armstrongs(int *array, int length) {
  

  for(int a = 0; a < length; a++)
  {
    if((array[a] > 0 && (array[a] < 10 || array[a] > 99)) && (strongarms(array[a] == 1)))
    {
      
      array[a] = array[a] * array[a];
    }
    
    
  }
}




// Take an array of integers and length of the arrays as input and triple every
// happy number of that array
int find_happy(int in)
{
  int store = in;
  int send = 0;
  while(store != 0)
  {
    int temp = store % 10;
    send = send + (temp * temp);
    store = store / 10;
  }
  return send;
}
void triple_happy(int *array, int length) {
  ////def of a happy number: goes up and it goes down for a happy number 
  /*
  happy number 7:

  7 -> 49 
  49 -> 4^2 + 9^2 = 16 + 81 = 97
  97 -> 9^2 + 7^2 = 81 + 49 = 130
  130 -> 1^2 + 3^2 + 0^2 = 10
  10 -> 1^2 + 0^2 = 1

  will have to use modulus for this :/ 
  */
for(int a = 0; a < length; a++) {
        int num = array[a];
        while (num != 1 && num != 4) {
            int store = num;
            int send = 0;
            while(store != 0) {
                int temp = store % 10;
                send = send + (temp * temp);
                store = store / 10;
            }
            num = send;
        }
        if(num == 1) {
            array[a] = array[a] * 3;
        }
    }
}
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab1-Kuria-MBA */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab1-Kuria-MBA */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab1-Kuria-MBA */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab1-Kuria-MBA */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab1-Kuria-MBA */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab1-Kuria-MBA */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab1-Kuria-MBA */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab1-Kuria-MBA */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab1-Kuria-MBA */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab1-Kuria-MBA */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab1-Kuria-MBA *//*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab1-Kuria-MBA */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab1-Kuria-MBA */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab1-Kuria-MBA */
