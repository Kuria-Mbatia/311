/* Author:    
   Date:
    */
    
    
    
/***
 *      ______ .___  ___. .______     _______.  ______              ____    __   __  
 *     /      ||   \/   | |   _  \   /       | /      |            |___ \  /_ | /_ | 
 *    |  ,----'|  \  /  | |  |_)  | |   (----`|  ,----'              __) |  | |  | | 
 *    |  |     |  |\/|  | |   ___/   \   \    |  |                  |__ <   | |  | | 
 *    |  `----.|  |  |  | |  |   .----)   |   |  `----.             ___) |  | |  | | 
 *     \______||__|  |__| | _|   |_______/     \______|            |____/   |_|  |_| 
 *                                                                                   
 */

#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
#include "mdadm.h"
#include "jbod.h"
#include "util.h"
int mounted = 0;

uint32_t op_code(jbod_cmd_t com, int disk_num, int block_num) {
    uint32_t op = (disk_num << 28)|block_num << 20 |(com << 14);
    return(op);///grabbing the correct section of the oepration 
}

int mdadm_mount(void) {
    if (mounted) {//if already mounted dont mount again
        return -1;
    }
    jbod_operation(op_code(JBOD_MOUNT, 0, 0), NULL);
    mounted = 1;//cahnge mount
    return 1;
}

int mdadm_unmount(void) {///ROD mdadm_mount :/ 
    if (!mounted) {
        return -1;
    }
    jbod_operation(op_code(JBOD_UNMOUNT, 0, 0), NULL);
    mounted = 0;
    return 1;
}




int mdadm_read(uint32_t addr, uint32_t len, uint8_t *buf) {
    if (!len) {
        return 0; 
    }
    if (!mounted || len > 1024 || buf == NULL || addr + len > JBOD_NUM_DISKS * JBOD_DISK_SIZE) {
        return -1; // Invalid parameters
    }
    ///printf("\nsize we are given: %d\n",len);
    uint32_t ref_addy = addr;
    uint32_t end_addr = addr + len;
    uint8_t *buf_ptr = buf;
    ///have to go through each individual disk, find the disk with the address and read it 
    uint32_t block_counter = 0;
    
    
    
    while (ref_addy < end_addr) {//linear search operation
        int disk_num = ref_addy / JBOD_DISK_SIZE;///disk = current addres divided by the disk size///verify looking


        int block_num = (ref_addy % JBOD_DISK_SIZE) / JBOD_BLOCK_SIZE;///block = current address mod disk size divided by block size
        ///printf("\nDisk_Num: %d\n",disk_num);
        int block_offset = ref_addy % JBOD_BLOCK_SIZE;////this may be a problem 
        int read_len = JBOD_BLOCK_SIZE - block_offset;
        
        
        
        if (ref_addy + read_len > end_addr) {
            read_len = end_addr - ref_addy;
            ///printf("WE change the read_len to: %d\n", read_len);
            ////how about stopping partway and then shifting to the next one 
        }
        /////this condition is not correct for reading accross the block (everything else is alright)
        
        ///printf("Disk address we are at: %d\nblock number we are at: %d\n", disk_num,block_num);
        uint8_t block[JBOD_BLOCK_SIZE];
        
        //printf("Verify we are at correct disk: %p\n",buf_ptr);
        
        /*
        ensure that the jbod_operation function correctly interprets 
        this operation and reads data into the block buffer accurately. 
        If there's an issue with how jbod_operation interprets the command 
        or accesses the simulated JBOD device, it might not return the correct data.

        *Keep recieving the same result even after changing the valeus obtianed :(
        */
        ///printf("Verify we are at correct disk: %d\n",disk_num);
        jbod_operation(op_code(JBOD_SEEK_TO_DISK, disk_num, 0), NULL);
        
        ///printf("Verify we are at correct block: %d\n",block_num);
        
        jbod_operation(op_code(JBOD_SEEK_TO_BLOCK, block_counter, block_num), NULL);

        
        jbod_operation(op_code(JBOD_READ_BLOCK, 0, 0), block);

        //attempt at mounting the mem buf and copying only what is wanted 
        memcpy(buf_ptr, block + block_offset, read_len);
        
        ///printf("Current block counter: %d\nRead Length: %d\n",block_counter,read_len);
        ref_addy += read_len;
        buf_ptr += read_len;
        block_counter++;
    }

    return len; // Successfully read
}

int mdadm_write(uint32_t addr, uint32_t len, const uint8_t *buf) {
    ////refer to the same comments that were in lab 2 again for the intitial portion :/
    if (!len) {
        return 0;
    }
    if (!mounted || len > 1024 || buf == NULL || addr + len > JBOD_NUM_DISKS * JBOD_DISK_SIZE) {
        return -1; // Invalid parameters
    }
    ///printf("\n\nInformation we are given: Address:%d | Length: %d\n",addr,len);
    uint32_t ref_addr = addr;
    uint32_t end_addr = addr + len;
    uint32_t block_counter = 0;
    const uint8_t *buf_ptr = buf;

    while (ref_addr < end_addr) {
        int disk_num = ref_addr / JBOD_DISK_SIZE;
        int block_num = (ref_addr % JBOD_DISK_SIZE) / JBOD_BLOCK_SIZE;
        int block_offset = ref_addr % JBOD_BLOCK_SIZE;
        int write_len = JBOD_BLOCK_SIZE - block_offset;

        if (ref_addr + write_len > end_addr) {
            write_len = end_addr - ref_addr;
        }
        //printf("Write Length: %d\n",write_len);
        uint8_t block[JBOD_BLOCK_SIZE];




        jbod_operation(op_code(JBOD_SEEK_TO_DISK, disk_num, 0), NULL);
        
        jbod_operation(op_code(JBOD_SEEK_TO_BLOCK, block_counter, block_num), NULL);
        
        jbod_operation(op_code(JBOD_READ_BLOCK, 0, 0), block);
        
        ///After this operation completes, the CurrentBlockID in I/O position is incremented by 1
        ///reading is not the go to, It is a bit bad to assume that we should read from the disk when we don't need to :/ 
        
        memcpy(block + block_offset, buf_ptr, write_len);
        
        jbod_operation(op_code(JBOD_SEEK_TO_DISK, disk_num, 0), NULL);
        
        jbod_operation(op_code(JBOD_SEEK_TO_BLOCK, block_counter, block_num), NULL);
        ////repeating seeking both the block and disk to ensure that we are referencing hte corerct section for writing
        ///primarily to ensure that we pass linear & Random traces :/

        jbod_operation(op_code(JBOD_WRITE_BLOCK, 0, block_num), block);
        
        
        
        ref_addr += write_len;
        buf_ptr += write_len;
        block_offset = 0;
        block_num++;
        
    }


    return len; // Successfully written
}



/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
/*CWD /home/kuriambatia/Desktop/CS_311_Labs/sp24-lab3-Kuria-MBA-main */
